import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Card, CardContent } from "@/Components/ui/card";

export default function TeamDetailsPage() {
  const { id } = useParams();
  const [teamData, setTeamData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTeamData = async () => {
      try {
        const response = await fetch(`http://localhost:5000/api/teams/${id}`);
        const data = await response.json();
        setTeamData(data);
      } catch (error) {
        console.error('Error fetching team data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTeamData();
  }, [id]);

  if (loading) return <div>Loading...</div>;
  if (!teamData) return <div>Team not found</div>;

  return (
    <div className="container mx-auto py-12">
      <h1 className="text-4xl font-bold text-black mb-8">{teamData.team.game_name}</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <h2 className="text-2xl font-semibold text-white">Team Information</h2>
          <p className="text-gray-300">{teamData.team.description}</p>
        </div>

        <div>
          <h2 className="text-2xl font-semibold text-black mb-6">Players</h2>
          <div className="space-y-4">
            {teamData.players.map((player, index) => (
              <Card key={index} className="bg-gray-900 border-semored">
                <CardContent className="p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-xl font-bold text-white">{player.player_name}</h3>
                      <p className="text-semored">{player.role}</p>
                    </div>
                    <span className="text-gray-400 text-sm">#{player.student_id}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}